/**
 * ==========================================================
 * MARS SOFTWARE PROJECT
 * ----------------------------------------------------------
 * Service:
 * FaceFoundationEngine
 *
 * Purpose:
 * Provides the first face/head foundation layer for the MARS
 * Vision Pipeline.
 *
 * This is NOT face recognition.
 * This engine estimates whether a head/face is visible and
 * derives approximate head orientation from MediaPipe pose
 * landmarks. It produces structured observations for future
 * Personal Observation Engine work.
 *
 * Version:
 * v0.11.0
 *
 * Date Code:
 * 280626
 * ==========================================================
 */

import {
  OBSERVATIONS,
  createObservation,
} from '@/core/observations/ObservationRegistry'

class FaceFoundationEngine {
  evaluate(poseResult, poseSummary) {
    const landmarks = poseResult?.landmarks || []

    if (!poseResult?.poseDetected || landmarks.length < 13) {
      return this.emptyResult('No pose landmarks available for head orientation.')
    }

    const nose = landmarks[0]
    const leftEye = landmarks[2]
    const rightEye = landmarks[5]
    const leftEar = landmarks[7]
    const rightEar = landmarks[8]
    const leftShoulder = landmarks[11]
    const rightShoulder = landmarks[12]

    const headLandmarks = [nose, leftEye, rightEye, leftEar, rightEar]
    const visibleHeadLandmarks = headLandmarks.filter((landmark) =>
      this.isVisible(landmark)
    )

    const faceDetected = this.isVisible(nose) && visibleHeadLandmarks.length >= 2

    if (!faceDetected) {
      return this.emptyResult('Head landmarks are not visible enough for estimation.')
    }

    const shoulderWidth = Math.max(
      0.01,
      Math.abs((leftShoulder?.x || 0) - (rightShoulder?.x || 0))
    )

    const shoulderMidX = this.average([leftShoulder?.x, rightShoulder?.x])
    const shoulderMidY = this.average([leftShoulder?.y, rightShoulder?.y])
    const eyeMidX = this.average([leftEye?.x, rightEye?.x])
    const eyeMidY = this.average([leftEye?.y, rightEye?.y])

    const yawScore = this.calculateYawScore(
      nose,
      eyeMidX,
      shoulderMidX,
      shoulderWidth,
      leftEar,
      rightEar
    )

    const pitchScore = this.calculatePitchScore(
      nose,
      eyeMidY,
      shoulderMidY,
      shoulderWidth,
      poseSummary
    )

    const rollScore = this.calculateRollScore(leftEye, rightEye)

    const yaw = this.classifyYaw(yawScore)
    const pitch = this.classifyPitch(pitchScore)
    const roll = this.classifyRoll(rollScore)
    const observations = this.createHeadObservations(pitch, yaw)
    const confidence = this.calculateConfidence(visibleHeadLandmarks.length, poseSummary)

    return {
      status: 'success',
      faceDetected,
      faceCount: 1,
      confidence,
      head: {
        visible: true,
        pitch,
        yaw,
        roll,
        pitchScore: Number(pitchScore.toFixed(3)),
        yawScore: Number(yawScore.toFixed(3)),
        rollScore: Number(rollScore.toFixed(3)),
        orientation: this.getOrientationLabel(pitch, yaw),
      },
      observations,
      riskModifier: 0,
      summary: `Face foundation: ${this.getOrientationLabel(pitch, yaw)} (${confidence}% confidence).`,
    }
  }

  calculateYawScore(nose, eyeMidX, shoulderMidX, shoulderWidth, leftEar, rightEar) {
    const noseReferenceX = Number.isFinite(eyeMidX) ? eyeMidX : shoulderMidX
    const noseOffset = ((nose?.x || 0) - noseReferenceX) / shoulderWidth

    const leftEarVisibility = this.visibility(leftEar)
    const rightEarVisibility = this.visibility(rightEar)
    const earVisibilityBalance = (rightEarVisibility - leftEarVisibility) * 0.15

    return noseOffset + earVisibilityBalance
  }

  calculatePitchScore(nose, eyeMidY, shoulderMidY, shoulderWidth, poseSummary) {
    const noseToEye = Number.isFinite(eyeMidY)
      ? (nose?.y || 0) - eyeMidY
      : 0

    const noseToShoulder = shoulderMidY - (nose?.y || shoulderMidY)
    const normalisedHeight = noseToShoulder / shoulderWidth
    const eyeDistanceEffect = noseToEye / shoulderWidth

    const upperBodyVisible = poseSummary?.bodyVisible ? 0.15 : 0

    return normalisedHeight - eyeDistanceEffect + upperBodyVisible
  }

  calculateRollScore(leftEye, rightEye) {
    if (!this.isVisible(leftEye) || !this.isVisible(rightEye)) {
      return 0
    }

    return (leftEye.y || 0) - (rightEye.y || 0)
  }

  classifyYaw(score) {
    if (score <= -0.18) return 'left'
    if (score >= 0.18) return 'right'
    return 'centre'
  }

  classifyPitch(score) {
    if (score >= 1.15) return 'up'
    if (score <= 0.55) return 'down'
    return 'level'
  }

  classifyRoll(score) {
    if (score <= -0.04) return 'tilted_left'
    if (score >= 0.04) return 'tilted_right'
    return 'level'
  }

  createHeadObservations(pitch, yaw) {
    const observations = [createObservation(OBSERVATIONS.HEAD_VISIBLE, 90)]

    if (pitch === 'up') {
      observations.push(createObservation(OBSERVATIONS.HEAD_UP, 80))
    }

    if (yaw === 'left') {
      observations.push(createObservation(OBSERVATIONS.HEAD_LEFT, 80))
    }

    if (yaw === 'right') {
      observations.push(createObservation(OBSERVATIONS.HEAD_RIGHT, 80))
    }

    if (pitch === 'up' && yaw === 'left') {
      observations.push(createObservation(OBSERVATIONS.HEAD_UP_LEFT, 75))
    }

    if (pitch === 'up' && yaw === 'right') {
      observations.push(createObservation(OBSERVATIONS.HEAD_UP_RIGHT, 75))
    }

    if (pitch === 'level' && yaw === 'centre') {
      observations.push(createObservation(OBSERVATIONS.HEAD_LEVEL, 80))
    }

    return observations
  }

  getOrientationLabel(pitch, yaw) {
    if (pitch === 'up' && yaw === 'left') return 'Head up and left'
    if (pitch === 'up' && yaw === 'right') return 'Head up and right'
    if (pitch === 'up') return 'Head raised'
    if (pitch === 'down') return 'Head lowered'
    if (yaw === 'left') return 'Looking left'
    if (yaw === 'right') return 'Looking right'
    return 'Head level'
  }

  calculateConfidence(visibleHeadLandmarks, poseSummary) {
    const landmarkScore = Math.min(70, visibleHeadLandmarks * 14)
    const bodyScore = poseSummary?.bodyVisible ? 20 : 0
    const stabilityScore = poseSummary?.confidence ? Math.min(10, poseSummary.confidence / 10) : 0

    return Math.round(Math.min(100, landmarkScore + bodyScore + stabilityScore))
  }

  average(values) {
    const validValues = values.filter((value) => Number.isFinite(value))

    if (!validValues.length) {
      return Number.NaN
    }

    return validValues.reduce((sum, value) => sum + value, 0) / validValues.length
  }

  visibility(landmark) {
    if (!landmark) return 0
    if (typeof landmark.visibility === 'number') return landmark.visibility
    if (typeof landmark.presence === 'number') return landmark.presence
    return 1
  }

  isVisible(landmark) {
    return Boolean(landmark) && this.visibility(landmark) >= 0.35
  }

  emptyResult(message) {
    return {
      status: 'not_available',
      faceDetected: false,
      faceCount: 0,
      confidence: 0,
      head: {
        visible: false,
        pitch: 'unknown',
        yaw: 'unknown',
        roll: 'unknown',
        pitchScore: 0,
        yawScore: 0,
        rollScore: 0,
        orientation: 'Unknown',
      },
      observations: [createObservation(OBSERVATIONS.HEAD_NOT_VISIBLE, 0)],
      riskModifier: 0,
      summary: `Face foundation: ${message}`,
    }
  }
}

export default new FaceFoundationEngine()
